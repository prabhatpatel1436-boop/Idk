import StatsSection from '../StatsSection';

export default function StatsSectionExample() {
  return <StatsSection />;
}
