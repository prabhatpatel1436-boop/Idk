import DiscordCTA from '../DiscordCTA';

export default function DiscordCTAExample() {
  return <DiscordCTA />;
}
