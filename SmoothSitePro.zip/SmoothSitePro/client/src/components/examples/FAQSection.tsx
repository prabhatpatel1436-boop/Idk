import FAQSection from '../FAQSection';

export default function FAQSectionExample() {
  return <FAQSection />;
}
