import FeatureDeepDive from '../FeatureDeepDive';

export default function FeatureDeepDiveExample() {
  return <FeatureDeepDive />;
}
