import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { SiDiscord } from "react-icons/si";
import { ThemeToggle } from "@/components/ThemeToggle";
import { motion, AnimatePresence } from "framer-motion";
import { usePrefersReducedMotion } from "@/hooks/use-prefers-reduced-motion";

export default function Navigation() {
  const prefersReducedMotion = usePrefersReducedMotion();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  if (prefersReducedMotion) {
    return (
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <img src="/bonzol-logo.png" alt="Bonzol Logo" className="w-8 h-8 object-contain" />
              <span className="font-display font-bold text-xl">BonelzBot</span>
            </div>

            <div className="hidden md:flex items-center gap-8">
              <button
                onClick={() => scrollToSection('features')}
                className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                data-testid="link-features"
              >
                Features
              </button>
              <button
                onClick={() => scrollToSection('pricing')}
                className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                data-testid="link-pricing"
              >
                Pricing
              </button>
              <button
                onClick={() => scrollToSection('faq')}
                className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                data-testid="link-faq"
              >
                FAQ
              </button>
            </div>

            <div className="hidden md:flex items-center gap-2">
              <ThemeToggle />
              <Button asChild data-testid="button-join-discord">
                <a href="https://discord.gg/FE7Ctv7dsE" target="_blank" rel="noopener noreferrer" className="gap-2">
                  <SiDiscord className="w-4 h-4" />
                  Join Discord
                </a>
              </Button>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden"
              data-testid="button-menu-toggle"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden bg-background border-t border-border">
            <div className="px-6 py-4 space-y-3">
              <button
                onClick={() => scrollToSection('features')}
                className="block w-full text-left py-2 text-sm font-medium text-muted-foreground hover:text-foreground"
                data-testid="link-features-mobile"
              >
                Features
              </button>
              <button
                onClick={() => scrollToSection('pricing')}
                className="block w-full text-left py-2 text-sm font-medium text-muted-foreground hover:text-foreground"
                data-testid="link-pricing-mobile"
              >
                Pricing
              </button>
              <button
                onClick={() => scrollToSection('faq')}
                className="block w-full text-left py-2 text-sm font-medium text-muted-foreground hover:text-foreground"
                data-testid="link-faq-mobile"
              >
                FAQ
              </button>
              <div className="flex items-center gap-2">
                <ThemeToggle />
                <Button asChild className="flex-1 gap-2" data-testid="button-join-discord-mobile">
                  <a href="https://discord.gg/FE7Ctv7dsE" target="_blank" rel="noopener noreferrer">
                    <SiDiscord className="w-4 h-4" />
                    Join Discord
                  </a>
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>
    );
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <img src="/bonzol-logo.png" alt="Bonzol Logo" className="w-8 h-8 object-contain" />
            <span className="font-display font-bold text-xl">BonelzBot</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => scrollToSection('features')}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              data-testid="link-features"
            >
              Features
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              data-testid="link-pricing"
            >
              Pricing
            </button>
            <button
              onClick={() => scrollToSection('faq')}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              data-testid="link-faq"
            >
              FAQ
            </button>
          </div>

          <div className="hidden md:flex items-center gap-2">
            <ThemeToggle />
            <Button asChild data-testid="button-join-discord">
              <a href="https://discord.gg/FE7Ctv7dsE" target="_blank" rel="noopener noreferrer" className="gap-2">
                <SiDiscord className="w-4 h-4" />
                Join Discord
              </a>
            </Button>
          </div>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden"
            data-testid="button-menu-toggle"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden bg-background border-t border-border overflow-hidden"
          >
            <div className="px-6 py-4 space-y-3">
              <button
                onClick={() => scrollToSection('features')}
                className="block w-full text-left py-2 text-sm font-medium text-muted-foreground hover:text-foreground"
                data-testid="link-features-mobile"
              >
                Features
              </button>
              <button
                onClick={() => scrollToSection('pricing')}
                className="block w-full text-left py-2 text-sm font-medium text-muted-foreground hover:text-foreground"
                data-testid="link-pricing-mobile"
              >
                Pricing
              </button>
              <button
                onClick={() => scrollToSection('faq')}
                className="block w-full text-left py-2 text-sm font-medium text-muted-foreground hover:text-foreground"
                data-testid="link-faq-mobile"
              >
                FAQ
              </button>
              <div className="flex items-center gap-2">
                <ThemeToggle />
                <Button asChild className="flex-1 gap-2" data-testid="button-join-discord-mobile">
                  <a href="https://discord.gg/FE7Ctv7dsE" target="_blank" rel="noopener noreferrer">
                    <SiDiscord className="w-4 h-4" />
                    Join Discord
                  </a>
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}