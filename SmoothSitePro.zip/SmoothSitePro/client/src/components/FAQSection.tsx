import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FAQSection() {
  const faqs = [
    {
      question: "Is BonelzBot safe and undetectable?",
      answer: "Yes! BonelzBot uses advanced human behavior simulation including ghost clicks, random offsets, jittered drag paths, and variable pause windows. It mimics natural player behavior so closely that it remains completely undetectable by game anti-cheat systems. We've had over 700 users with zero ban reports."
    },
    {
      question: "What features does BonelzBot include?",
      answer: "BonelzBot includes auto-attack (starts battles automatically), army flexibility (use any troop composition), auto wall upgrades (spends resources intelligently), smart scanning (only attacks profitable villages), random actions (human-like behavior), error recovery (keeps running if issues occur), live logs with hotkeys, and a user-friendly GUI interface."
    },
    {
      question: "How much does BonelzBot cost?",
      answer: "BonelzBot Night Village Edition is available for €7.99-9.99 EUR (approximately $9.59-11.59 USD) as a one-time payment for a lifetime license. We also offer wall upgrade services with custom pricing for TH9-TH17. Bulk purchases may qualify for negotiable discounts."
    },
    {
      question: "What Town Hall levels are supported?",
      answer: "BonelzBot fully supports Night Village automation for all Builder Base levels. Our wall upgrade service covers Town Hall 9 through Town Hall 17 in the main village, ensuring comprehensive support regardless of your progress level."
    },
    {
      question: "Can I customize the farming strategy?",
      answer: "Absolutely! BonelzBot provides extensive customization options. You can set gold, elixir, and dark elixir thresholds to control when attacks start, configure which troop slots to use, customize army compositions, set drop trophy limits, enable/disable wall upgrades, and adjust the number of walls to upgrade before stopping."
    },
    {
      question: "How does the wall upgrade automation work?",
      answer: "When your stored Gold or Elixir reaches double the cost of your cheapest available wall, BonelzBot automatically upgrades walls for you. You can configure how many walls to upgrade before the bot stops, ensuring you never waste resources and always maximize your base's defensive capabilities."
    },
    {
      question: "Do you offer customer support?",
      answer: "Yes! We provide comprehensive support through our Discord community at discord.gg/FE7Ctv7dsE. Our active community of 700+ users helps answer questions, and our support team is available to assist with setup, troubleshooting, and feature questions. Most inquiries are answered within hours."
    },
    {
      question: "How do I purchase BonelzBot?",
      answer: "All purchases are handled through our Discord server for security and instant delivery. Join our Discord at discord.gg/FE7Ctv7dsE, navigate to the purchase channel, and follow the instructions. You'll receive instant access to your license key and download links after payment confirmation."
    },
    {
      question: "Can I use BonelzBot on multiple accounts?",
      answer: "Each BonelzBot license is designed for a single account. However, the bot includes features to save and load different configurations, making it easy to switch between accounts. For managing multiple accounts simultaneously, please contact us on Discord for multi-license pricing options."
    },
    {
      question: "What happens if there's an error or game update?",
      answer: "BonelzBot includes advanced error recovery that automatically detects and handles common issues, keeping the bot running smoothly. For game updates, we monitor Clash of Clans closely and push updates to BonelzBot quickly to ensure compatibility. All updates are free for lifetime license holders."
    }
  ];

  return (
    <section id="faq" className="py-20 bg-background">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-4xl sm:text-5xl mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-foreground/75">
            Everything you need to know about BonelzBot
          </p>
        </div>

        <Accordion type="single" collapsible className="space-y-4" data-testid="faq-accordion">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="border border-border rounded-md px-6 hover-elevate transition-all"
              data-testid={`faq-item-${index}`}
            >
              <AccordionTrigger className="text-left font-semibold hover:no-underline">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-foreground/75 leading-relaxed">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
