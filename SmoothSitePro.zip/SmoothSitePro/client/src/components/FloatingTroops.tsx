import { motion } from "framer-motion";
import { usePrefersReducedMotion } from "@/hooks/use-prefers-reduced-motion";

export default function FloatingTroops() {
  const prefersReducedMotion = usePrefersReducedMotion();

  const troops = [
    {
      src: "/troops/clash-of-clans-archer-game-clash-royale-supercell-archer-347367b8991e62d77e48682197d21952.png",
      className: "absolute top-24 right-16 w-40 h-40 md:w-48 md:h-48 opacity-30",
      animation: { 
        duration: 18, 
        delay: 0, 
        x: [0, 45, -25, 0], 
        y: [0, -55, -35, 0], 
        rotate: [0, 15, -10, 0],
        scale: [1, 1.15, 0.92, 1]
      }
    },
    {
      src: "/troops/cheats-for-clash-of-clans-clash-royale-character-video-game-clash-of-clans-4c23845ade72224a49c704db4220f357.png",
      className: "absolute bottom-32 left-24 w-36 h-36 md:w-44 md:h-44 opacity-25",
      animation: { 
        duration: 22, 
        delay: 3, 
        x: [0, -40, 20, 0], 
        y: [0, 50, 28, 0], 
        rotate: [0, -12, 8, 0],
        scale: [1, 0.88, 1.08, 1]
      }
    },
    {
      src: "/troops/clash-of-clans-clash-royale-boom-beach-hay-day-game-clash-royale-fbcd56ff60f89a14f4503dec7a9df667.png",
      className: "absolute top-1/2 left-16 w-32 h-32 md:w-40 md:h-40 opacity-28",
      animation: { 
        duration: 20, 
        delay: 6, 
        x: [0, 30, -18, 0], 
        y: [0, -40, -22, 0], 
        rotate: [0, 20, -6, 0],
        scale: [1, 1.2, 0.9, 1]
      }
    },
    {
      src: "/troops/clash-of-clans-clash-royale-desktop-wallpaper-wizard-clash-of-clans-f59058bb9b01f5daa18573e5394355a4.png",
      className: "absolute top-40 left-1/3 w-[152px] h-[152px] md:w-[184px] md:h-[184px] opacity-22",
      animation: { 
        duration: 24, 
        delay: 2, 
        x: [0, -35, 25, 0], 
        y: [0, 45, 18, 0], 
        rotate: [0, -18, 12, 0],
        scale: [1, 0.85, 1.12, 1]
      }
    },
    {
      src: "/troops/clash-of-clans-clash-royale-video-gaming-clan-clash-royal-acfc45f7d42b08064f2edb283b256028.png",
      className: "absolute bottom-48 right-32 w-[136px] h-[136px] md:w-[168px] md:h-[168px] opacity-20",
      animation: { 
        duration: 23, 
        delay: 5, 
        x: [0, 42, -15, 0], 
        y: [0, -48, -20, 0], 
        rotate: [0, 16, -14, 0],
        scale: [1, 1.18, 0.94, 1]
      }
    },
    {
      src: "/troops/clash-royale-clash-of-clans-golem-coc-b58c90730b5b0d76c0ff4bc8625e07cf.png",
      className: "absolute top-2/3 right-20 w-[120px] h-[120px] md:w-[152px] md:h-[152px] opacity-24",
      animation: { 
        duration: 21, 
        delay: 8, 
        x: [0, -32, 22, 0], 
        y: [0, 38, 15, 0], 
        rotate: [0, -20, 10, 0],
        scale: [1, 0.92, 1.14, 1]
      }
    }
  ];

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {troops.map((troop, index) => (
        <motion.div
          key={index}
          className={troop.className}
          style={{
            willChange: prefersReducedMotion ? 'auto' : 'transform',
            transform: 'translate3d(0, 0, 0)',
          }}
          animate={prefersReducedMotion ? {} : {
            x: troop.animation.x,
            y: troop.animation.y,
            rotate: troop.animation.rotate,
            scale: troop.animation.scale,
          }}
          transition={prefersReducedMotion ? {} : {
            duration: troop.animation.duration,
            repeat: Infinity,
            ease: [0.45, 0, 0.55, 1],
            delay: troop.animation.delay,
            repeatType: "loop",
          }}
        >
          <img
            src={troop.src}
            alt=""
            className="w-full h-full rounded-2xl object-cover filter drop-shadow-2xl"
            loading="lazy"
          />
        </motion.div>
      ))}
    </div>
  );
}
