import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SiDiscord } from "react-icons/si";
import { PlayCircle, Settings, BarChart3, Shield } from "lucide-react";
import { motion } from "framer-motion";
import { usePrefersReducedMotion } from "@/hooks/use-prefers-reduced-motion";

export default function BotScreenshotSection() {
  const prefersReducedMotion = usePrefersReducedMotion();
  
  const highlights = [
    {
      icon: PlayCircle,
      title: "One-Click Control",
      description: "Start/Stop with hotkeys, save configs instantly"
    },
    {
      icon: BarChart3,
      title: "Live Statistics",
      description: "Real-time raid tracking, resource counting, efficiency metrics"
    },
    {
      icon: Settings,
      title: "Full Customization",
      description: "Troop slots, spell usage, loot thresholds, hero abilities"
    },
    {
      icon: Shield,
      title: "Safe & Reliable",
      description: "Ghost clicks, random delays, error recovery, zero bans"
    }
  ];

  return (
    <section className="py-20 bg-background relative overflow-hidden">
      {/* Decorative Troops */}
      {!prefersReducedMotion && (
        <>
          <motion.div
            className="absolute top-10 left-8 w-24 h-24 md:w-32 md:h-32 opacity-12 pointer-events-none"
            initial={{ opacity: 0, rotate: -20 }}
            whileInView={{ opacity: 0.12, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2 }}
          >
            <motion.img
              src="/troops/clash-of-clans-clash-royale-boom-beach-hay-day-game-clash-royale-fbcd56ff60f89a14f4503dec7a9df667.png"
              alt=""
              className="w-full h-full object-contain drop-shadow-2xl"
              animate={{ y: [0, -8, 0], rotate: [0, 3, -3, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            />
          </motion.div>
          
          <motion.div
            className="absolute bottom-16 right-12 w-28 h-28 md:w-36 md:h-36 opacity-10 pointer-events-none hidden md:block"
            initial={{ opacity: 0, scale: 0.5 }}
            whileInView={{ opacity: 0.10, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, delay: 0.3 }}
          >
            <motion.img
              src="/troops/cheats-for-clash-of-clans-clash-royale-character-video-game-clash-of-clans-4c23845ade72224a49c704db4220f357.png"
              alt=""
              className="w-full h-full object-contain drop-shadow-2xl"
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
            />
          </motion.div>
        </>
      )}
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div 
          className="text-center mb-12"
          initial={prefersReducedMotion ? {} : { opacity: 0, y: 20 }}
          whileInView={prefersReducedMotion ? {} : { opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <Badge variant="secondary" className="mb-4 text-xs uppercase tracking-wider">
            Professional Interface
          </Badge>
          <h2 className="font-display font-bold text-4xl sm:text-5xl mb-4">
            Control Panel Overview
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Clean, intuitive interface with all the power you need
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-12">
          <motion.div 
            className="order-2 lg:order-1"
            initial={prefersReducedMotion ? {} : { opacity: 0, x: -30 }}
            whileInView={prefersReducedMotion ? {} : { opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.div
              whileHover={prefersReducedMotion ? {} : { scale: 1.02, y: -5 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <Card className="p-4 hover-elevate transition-all">
                <div className="relative overflow-hidden rounded-lg">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-purple-500/10 blur-2xl"></div>
                  <img
                    src="/troops/clash-of-clans-clash-royale-desktop-wallpaper-wizard-clash-of-clans-f59058bb9b01f5daa18573e5394355a4.png"
                    alt="BonelzBot Control Panel Interface"
                    className="relative w-full rounded-lg shadow-xl border border-border"
                    data-testid="img-bot-main-screen"
                  />
                </div>
              </Card>
            </motion.div>
          </motion.div>

          <motion.div 
            className="order-1 lg:order-2 space-y-6"
            initial={prefersReducedMotion ? {} : { opacity: 0, x: 30 }}
            whileInView={prefersReducedMotion ? {} : { opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <div>
              <h3 className="font-display font-bold text-3xl mb-3">
                Everything You Need, Nothing You Don't
              </h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Our GUI is designed for efficiency. Live logs, instant controls, detailed statistics, and comprehensive configuration—all in one clean interface.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              {highlights.map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.div 
                    key={index} 
                    className="flex gap-3" 
                    data-testid={`highlight-${index}`}
                    initial={prefersReducedMotion ? {} : { opacity: 0, y: 20 }}
                    whileInView={prefersReducedMotion ? {} : { opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                    whileHover={prefersReducedMotion ? {} : { scale: 1.03, x: 5 }}
                  >
                    <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">{item.title}</h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            <motion.div 
              className="pt-4"
              initial={prefersReducedMotion ? {} : { opacity: 0 }}
              whileInView={prefersReducedMotion ? {} : { opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.8 }}
            >
              <motion.div whileHover={prefersReducedMotion ? {} : { scale: 1.05 }} whileTap={prefersReducedMotion ? {} : { scale: 0.98 }}>
                <Button asChild size="lg" className="gap-2" data-testid="button-get-access">
                  <a href="https://discord.gg/FE7Ctv7dsE" target="_blank" rel="noopener noreferrer">
                    <SiDiscord className="w-5 h-5" />
                    Get Instant Access
                  </a>
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
