import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Shield, Clock, Users, CheckCircle2, Zap } from "lucide-react";
import { SiDiscord } from "react-icons/si";
import { motion } from "framer-motion";
import AnimatedBackground from "@/components/AnimatedBackground";
import { usePrefersReducedMotion } from "@/hooks/use-prefers-reduced-motion";

export default function HeroSection() {
  const prefersReducedMotion = usePrefersReducedMotion();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  if (prefersReducedMotion) {
    return (
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-background via-background to-card pt-16">
        <AnimatedBackground />

        <div className="relative z-10 max-w-7xl mx-auto px-6 py-20">
          <div className="text-center max-w-4xl mx-auto mb-16">
            <div>
              <Badge variant="secondary" className="mb-6 text-xs uppercase tracking-wider" data-testid="badge-category">
                Premium Clash of Clans Automation
              </Badge>
            </div>
            
            <h1 className="font-display font-bold text-5xl sm:text-6xl lg:text-7xl mb-6 text-foreground leading-tight">
              Max Your Progress, Not Your Efforts
            </h1>
            
            <p className="text-lg sm:text-xl text-foreground/80 mb-8 leading-relaxed">
              700+ players trust BonelzBot for undetected, fully automated farming. Get your 6th builder without lifting a finger.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <div>
                <Button size="lg" asChild className="gap-2" data-testid="button-get-bonelzbot">
                  <a href="https://discord.gg/FE7Ctv7dsE" target="_blank" rel="noopener noreferrer">
                    <SiDiscord className="w-5 h-5" />
                    Get BonelzBot
                  </a>
                </Button>
              </div>
              <div>
                <Button size="lg" variant="outline" onClick={() => scrollToSection('features')} data-testid="button-view-features">
                  View Features
                </Button>
              </div>
            </div>

            <div className="flex flex-wrap gap-6 justify-center text-sm mb-16">
              {[
                { icon: Shield, text: "100% Undetectable" },
                { icon: Clock, text: "24/7 Support" },
                { icon: Users, text: "700+ Customers" },
              ].map((item, index) => (
                <div
                  key={item.text}
                  className="flex items-center gap-2 text-foreground/75"
                >
                  <item.icon className="w-4 h-4 text-primary" />
                  <span>{item.text}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <div>
              <Card className="p-6 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20 h-full transition-all duration-300 hover:shadow-xl hover:border-primary/40">
                <Zap className="w-8 h-8 text-primary mb-4" />
                <h3 className="font-semibold text-xl mb-2">Lightning Fast</h3>
                <p className="text-sm text-foreground/70 mb-4">
                  Advanced OCR-driven automation that mimics human behavior perfectly
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Auto-attack with any army</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Smart loot scanning</span>
                  </li>
                </ul>
              </Card>
            </div>

            <div>
              <Card className="p-6 bg-gradient-to-br from-purple-500/5 to-purple-500/10 border-purple-500/20 h-full transition-all duration-300 hover:shadow-xl hover:border-purple-500/40">
                <Shield className="w-8 h-8 text-purple-500 mb-4" />
                <h3 className="font-semibold text-xl mb-2">100% Safe</h3>
                <p className="text-sm text-foreground/70 mb-4">
                  Random actions and human-like delays keep you completely undetected
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                    <span>Ghost clicks & pauses</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                    <span>Random offsets</span>
                  </li>
                </ul>
              </Card>
            </div>

            <div>
              <Card className="p-6 bg-gradient-to-br from-blue-500/5 to-blue-500/10 border-blue-500/20 sm:col-span-2 lg:col-span-1 h-full transition-all duration-300 hover:shadow-xl hover:border-blue-500/40">
                <Users className="w-8 h-8 text-blue-500 mb-4" />
                <h3 className="font-semibold text-xl mb-2">Proven Track Record</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Trusted by 700+ players with zero ban reports
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                    <span>Lifetime license</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                    <span>Free updates forever</span>
                  </li>
                </ul>
              </Card>
            </div>
          </div>
        </div>

        <style>{`
          @keyframes float {
            0%, 100% { transform: translate(0, 0); }
            50% { transform: translate(20px, -20px); }
          }
        `}</style>
      </section>
    );
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-background via-background to-card pt-16">
      <AnimatedBackground />
      
      {/* Decorative Troops - Strategically Placed */}
      <motion.div
        className="absolute top-20 right-12 w-32 h-32 md:w-40 md:h-40 opacity-20 pointer-events-none z-0"
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 0.2, x: 0 }}
        transition={{ duration: 1, ease: "easeOut" }}
        whileHover={{ scale: 1.1, rotate: 5 }}
      >
        <motion.img
          src="/troops/clash-of-clans-archer-game-clash-royale-supercell-archer-347367b8991e62d77e48682197d21952.png"
          alt=""
          className="w-full h-full object-contain drop-shadow-2xl"
          animate={{ y: [0, -15, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        />
      </motion.div>
      
      <motion.div
        className="absolute bottom-32 left-16 w-36 h-36 md:w-44 md:h-44 opacity-18 pointer-events-none z-0"
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 0.18, x: 0 }}
        transition={{ duration: 1.2, delay: 0.2, ease: "easeOut" }}
        whileHover={{ scale: 1.1, rotate: -5 }}
      >
        <motion.img
          src="/troops/clash-royale-clash-of-clans-golem-coc-b58c90730b5b0d76c0ff4bc8625e07cf.png"
          alt=""
          className="w-full h-full object-contain drop-shadow-2xl"
          animate={{ y: [0, 12, 0] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
        />
      </motion.div>
      
      <motion.div
        className="absolute top-1/2 right-20 w-28 h-28 md:w-36 md:h-36 opacity-15 pointer-events-none z-0 hidden lg:block"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 0.15, scale: 1 }}
        transition={{ duration: 1.5, delay: 0.4, ease: "easeOut" }}
        whileHover={{ scale: 1.15, rotate: 8 }}
      >
        <motion.img
          src="/troops/clash-of-clans-clash-royale-video-gaming-clan-clash-royal-acfc45f7d42b08064f2edb283b256028.png"
          alt=""
          className="w-full h-full object-contain drop-shadow-2xl"
          animate={{ 
            y: [0, -10, 0],
            rotate: [0, 5, -5, 0]
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        />
      </motion.div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center max-w-4xl mx-auto mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Badge variant="secondary" className="mb-6 text-xs uppercase tracking-wider" data-testid="badge-category">
              Premium Clash of Clans Automation
            </Badge>
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="font-display font-bold text-5xl sm:text-6xl lg:text-7xl mb-6 text-foreground leading-tight"
          >
            Max Your Progress, Not Your Efforts
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg sm:text-xl text-foreground/80 mb-8 leading-relaxed"
          >
            700+ players trust BonelzBot for undetected, fully automated farming. Get your 6th builder without lifting a finger.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="flex flex-col sm:flex-row gap-4 justify-center mb-12"
          >
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button size="lg" asChild className="gap-2" data-testid="button-get-bonelzbot">
                <a href="https://discord.gg/FE7Ctv7dsE" target="_blank" rel="noopener noreferrer">
                  <SiDiscord className="w-5 h-5" />
                  Get BonelzBot
                </a>
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button size="lg" variant="outline" onClick={() => scrollToSection('features')} data-testid="button-view-features">
                View Features
              </Button>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-wrap gap-6 justify-center text-sm mb-16"
          >
            {[
              { icon: Shield, text: "100% Undetectable" },
              { icon: Clock, text: "24/7 Support" },
              { icon: Users, text: "700+ Customers" },
            ].map((item, index) => (
              <motion.div
                key={item.text}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.7 + index * 0.1 }}
                className="flex items-center gap-2 text-foreground/75"
              >
                <item.icon className="w-4 h-4 text-primary" />
                <span>{item.text}</span>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto"
        >
          <motion.div
            whileHover={{ scale: 1.03, y: -5 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <Card className="p-6 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20 h-full transition-all duration-300 hover:shadow-xl hover:border-primary/40">
            <Zap className="w-8 h-8 text-primary mb-4" />
            <h3 className="font-semibold text-xl mb-2 text-foreground">Lightning Fast</h3>
            <p className="text-sm text-foreground/70 mb-4">
              Advanced OCR-driven automation that mimics human behavior perfectly
            </p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                <span>Auto-attack with any army</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                <span>Smart loot scanning</span>
              </li>
            </ul>
          </Card>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.03, y: -5 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <Card className="p-6 bg-gradient-to-br from-purple-500/5 to-purple-500/10 border-purple-500/20 h-full transition-all duration-300 hover:shadow-xl hover:border-purple-500/40">
              <Shield className="w-8 h-8 text-purple-500 mb-4" />
              <h3 className="font-semibold text-xl mb-2 text-foreground">100% Safe</h3>
              <p className="text-sm text-foreground/70 mb-4">
                Random actions and human-like delays keep you completely undetected
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span>Ghost clicks & pauses</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span>Random offsets</span>
                </li>
              </ul>
            </Card>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.03, y: -5 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <Card className="p-6 bg-gradient-to-br from-blue-500/5 to-blue-500/10 border-blue-500/20 sm:col-span-2 lg:col-span-1 h-full transition-all duration-300 hover:shadow-xl hover:border-blue-500/40">
              <Users className="w-8 h-8 text-blue-500 mb-4" />
              <h3 className="font-semibold text-xl mb-2 text-foreground">Proven Track Record</h3>
              <p className="text-sm text-foreground/70 mb-4">
                Trusted by 700+ players with zero ban reports
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span>Lifetime license</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span>Free updates forever</span>
                </li>
              </ul>
            </Card>
          </motion.div>
        </motion.div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translate(0, 0); }
          50% { transform: translate(20px, -20px); }
        }
      `}</style>
    </section>
  );
}
