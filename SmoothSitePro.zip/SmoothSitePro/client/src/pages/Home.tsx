import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import StatsSection from "@/components/StatsSection";
import MotivationalSection from "@/components/MotivationalSection";
import FeaturesSection from "@/components/FeaturesSection";
import BotScreenshotSection from "@/components/BotScreenshotSection";
import LiveDemoSection from "@/components/LiveDemoSection";
import FeatureDeepDive from "@/components/FeatureDeepDive";
import PricingSection from "@/components/PricingSection";
import FAQSection from "@/components/FAQSection";
import DiscordCTA from "@/components/DiscordCTA";
import Footer from "@/components/Footer";
import ParticleEffect from "@/components/ParticleEffect";
import ScrollReveal from "@/components/ScrollReveal";

export default function Home() {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <ParticleEffect />
      <Navigation />
      <HeroSection />
      
      <ScrollReveal>
        <StatsSection />
      </ScrollReveal>
      
      <ScrollReveal direction="fade" delay={0.2}>
        <MotivationalSection />
      </ScrollReveal>
      
      <ScrollReveal direction="up" delay={0.1}>
        <FeaturesSection />
      </ScrollReveal>
      
      <ScrollReveal direction="left" delay={0.15}>
        <BotScreenshotSection />
      </ScrollReveal>
      
      <ScrollReveal direction="right" delay={0.1}>
        <LiveDemoSection />
      </ScrollReveal>
      
      <ScrollReveal direction="up" delay={0.2}>
        <FeatureDeepDive />
      </ScrollReveal>
      
      <ScrollReveal direction="fade" delay={0.15}>
        <PricingSection />
      </ScrollReveal>
      
      <ScrollReveal direction="up" delay={0.1}>
        <FAQSection />
      </ScrollReveal>
      
      <ScrollReveal direction="fade" delay={0.2}>
        <DiscordCTA />
      </ScrollReveal>
      
      <Footer />
    </div>
  );
}
